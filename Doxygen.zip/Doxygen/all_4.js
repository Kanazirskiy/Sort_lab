var searchData=
[
  ['partition_0',['Partition',['../main_8cpp.html#ab26a1db8e70d083beeabe31dbd9beecf',1,'main.cpp']]]
];
